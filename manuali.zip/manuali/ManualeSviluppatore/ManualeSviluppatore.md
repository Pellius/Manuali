# MANUALE SVILUPPATORE 

## Inizio

>[!IMPORTANTE]
>
>Questo è il manuale sviluppatore, tutto quello che verrà scritto sarà inerente esclusivamente al come è stata sviluppata l'applicazione.

<br>

# Backend

# Progettazione DB 

Per progettare il DB, si crea una bozza, ovviamente questo lo si usa come prova.

Fatto questo, si procede a impostarlo su MySql o su qualsiasi altro DB.

Nello sviluppo del DB, sono state individuate **11 tabelle**:

<br>

**QUESTE SONO LE TABELLE ENTITÁ**

| Notes | Tags | Documents | Folders | Sub_folders | Users |
|--- |--- |--- | --- | --- | --- |
| id | id | id | id  | id   | id |
| name | name  | name | name | name | name  
| content | created_at    | icon | icon | icon | email
| user_id | updated_at     | path | path  | path | usertype
| created_at | | mime | user_id | user_id | email_verified_at
| updated_at      |    | extension |created_at    | created_at           | password
|         |    | user_id | updated_at       | updated_at         | remember_token
|         |    | note_id |      |         | created_at  |
|         |    | created_at |      |         | updated_at  |
|         |    | updated_at  |      |         | |

<br>

**QUESTE SONO LE TABELLE ASSOCIATIVE**

| Documents_tags | Folders_documents | Folders_subfolders | Subfolders_documents | Tags_users
|--- |--- |--- | --- | --- | 
|id | id | id | id | id
| document_id | folder_id | folder_id | subfolder_id | tag_id
| tag_id | document_id | subfolder_id | document_id |  user_id
| created_at | created_at | created_at | created_at |  created_at
| updated_at | updated_at | updated_at | updated_at |  updated_at

<br>

**QUESTE SONO LE RELAZIONI**

- Notes <-> Users: una relazione 1:N, una nota può essere creata da uno user solo mentre uno user può creare una o più note.

- Documents <-> Users: una relazione 1:N, un documento deve essere creato da uno user solo mentre uno user deve creare uno o più documenti.

- Documents <-> Notes: una relazione 1:N, un documento può prensentare una nota sola mentre una nota può essere presente in uno o più documenti.

- Subfolders <-> Users: una relazione 1:N, una sottocartella può essere creata da uno user solo mentre uno user può creare uno o più sottocartelle.

- Folders <-> Users: una relazione 1:N, una cartella può essere creata da uno user solo mentre uno user deve creare una o più cartelle.

- Documents <-> Tags: una relazione N:N, uno o più documenti devono contenere uno o più tag mentre uno o più tag devono essere contenuti in uno o più documenti.

- Folders <-> Documents: una relazione N:N, uno o più cartelle devono contenere uno o più documenti mentre uno o più documenti devono essere contenuti in una o più cartelle .

- Folders <-> Subfolders: una relazione N:N, una o più cartelle possono contenere uno o più sottocartelle mentre uno o più sottocartelle possono essere contenute in una o più cartelle.

- Subfolders <-> Documents: una relazione N:N, uno o più sottocartelle possono contenere uno o più documenti mentre uno o più documenti possono essere contenuti in una o più sottocartelle.

- Tags <-> Users: una relazione N:N, uno o più tag devono essere creati da uno o più utenti mentre uno o più utenti devono creare uno o più tag.

<br>

>[!IMPORTANTE]
>
>Ogni tabella come default ha i timestamp, quindi created_at e updated_at, inoltre, la prima volta che si esegue la migrate, si vanno ad aggiungere altre 8 tabelle: 
> - cache_locks
> - cache
> - failed_jobs
> - jobs
> - jobs_batches
> - migrations
> - password_reset_tokens
> - sessions 


## Comandi migration

Comando per creare una migration 

``` bash
php artisan make:migration nomeMigration
```

Esempio di migration:

``` php


use Illuminate\Database\Migrations\Migration;
use Illuminate\Database\Schema\Blueprint;
use Illuminate\Support\Facades\Schema;

return new class extends Migration
{
    /**
     * Esegue la migrazione
     */
    public function up(): void
    {
        Schema::create('notes', function (Blueprint $table) {
            $table->id();
            $table->string('name');
            $table->text('content');
            $table->foreignId('user_id')->constrained('users');
            $table->timestamps();
        });
    }

    /**
     * Annulla la migrazione
     */
    public function down(): void
    {
        Schema::dropIfExists('notes');
    }
};

```

Comando per eseguire una migrate 

``` bash
php artisan migrate
```

Comando per eseguire un fresh 

``` bash
php artisan migrate:fresh
```
Comando per eseguire un rollback 

``` bash
php artisan migrate:rollback
```

Comando per indicare di quante tabelle si vuole effettuare il rollback 

``` bash
php artisan migrate:rollback  --step=2
```

<br>

Di default il DB avrà queste configurazioni

``` php
DB_CONNECTION=sqlite
# DB_HOST=127.0.0.1
# DB_PORT=3306
# DB_DATABASE=laravel
# DB_USERNAME=root
# DB_PASSWORD=
```

Se si esegue il migrate senza avere un DB, verrà dato questo messaggio:

![screen](./img/bash.PNG)

Se si seleziona yes, chiederà quale DB si vuole utilizzare ed effettuerà la migrate, modificando il file **.env** in questo modo:

``` php
DB_CONNECTION=mysql
DB_HOST=127.0.0.1
DB_PORT=3306
DB_DATABASE=nomedb
DB_USERNAME=root
DB_PASSWORD=
```

Dopo aver fatto tutto si può startare il server 


## Comando server 

Comando per startare il server
``` bash
php artisan serve
```

Successivamente, si passa allo sviluppo tramite l'utilizzo di un IDE qualsiasi, per esempio Visual Studio Code. 


>[!IMPORTANTE]
>
> Si utilizza Laravel con lo starter kit Breeze insieme a Vue, più completo rispetto a Laravel puro, contiene librerie che permettono l'implementazione dello user e l'utilizzo di componenti già messi a disposizione per il frontend.

In aggiunta carica il json con le configurazioni per l'utilizzo dell'app, situata nella sottocartella **js** che si trova all'interno di **resources**. 

app.js


``` Javascript

import '../css/app.css';
import './bootstrap';

import { createInertiaApp } from '@inertiajs/vue3';
import { resolvePageComponent } from 'laravel-vite-plugin/inertia-helpers';
import { createApp, h } from 'vue';
import { ZiggyVue } from '../../vendor/tightenco/ziggy';

const appName = import.meta.env.VITE_APP_NAME || 'Laravel';

createInertiaApp({
    title: (title) => `${title} - ${appName}`,
    resolve: (name) =>
        resolvePageComponent(
            `./Pages/${name}.vue`,
            import.meta.glob('./Pages/**/*.vue'),
        ),
    setup({ el, App, props, plugin }) {
        return createApp({ render: () => h(App, props) })
            .use(plugin)
            .use(ZiggyVue)
            .mount(el);
    },
    progress: {
        color: '#4B5563',
    },
});
``` 

<br>

# Models

Dopo la parte introduttiva, si parte con la definizione dei Models

Esempio:

Document.php

``` PHP 


namespace App\Models;

use Illuminate\Database\Eloquent\Factories\HasFactory;
use Illuminate\Database\Eloquent\Builder;
use Illuminate\Http\Request;
use Illuminate\Database\Eloquent\Model;

// Classe Documento
class Document extends Model
{
    // Permette l'utilizzo delle factory
    use HasFactory;

    // Dichiarazione dei campi che possono essere assegnati
    protected $fillable = [
        'name',
        'icon',
        'path',
        'extension',
        'mime',
        'user_id',
        'note_id'
    ];

    // Gestione delle relazioni
    public function folders(){
        return $this->belongsToMany(Folder::class, 'folders_documents');
    }

    public function user(){
        return $this->belongsTo(User::class);
    }

    public function tags(){
        return $this->belongsToMany(Tag::class, 'documents_tags');
    }

    public function note(){
        return $this->belongsTo(Note::class);
    }

    public function subfolders(){
        return $this->belongsToMany(SubFolder::class, 'subfolders_documents');
    }

    // Funzione che permette la ricerca di un documento in base a specifici campi
    public function scopeSearch(Builder $query, Request $request)  // Query per la ricerca
    {
        return $query->where(function ($query) use ($request) {  // Questa permette di raggruppare le condizioni
            return $query->when($request->search, function ($query) use ($request) { // Questa verifica se nella richiesta è presente il parametro search
                return $query->where(function ($query) use ($request) { // Se presente esegue una where per filtrare la ricerca per nome, estensione, mime, tag, user e contenuto
                    $query->where('documents.name', 'like', '%' . $request->search . '%')
                        ->orWhere('documents.extension', 'like', '%' . $request->search . '%')
                        ->orWhere('documents.mime', 'like', '%' . $request->search . '%')
                        ->orWhereHas('tags', function ($tagQuery) use ($request) {
                            $tagQuery->where('tags.name', 'like', '%' . $request->search . '%');
                        })
                        ->orWhereHas('user', function ($userQuery) use ($request) {
                            $userQuery->where('users.name', 'like', '%' . $request->search . '%');
                        })
                        ->orWhereHas('note', function ($noteQuery) use ($request) {
                            $noteQuery->where('notes.name', 'like', '%' . $request->search . '%');
                        });
                });
            })->when($request->name, function ($query) use ($request) { // Verifica se nella richiesta è presente il nome del documento
                    return $query->where('documents.id', $request->name);
            })->when($request->user_id, function ($query) use ($request) { // Verifica se nella richiesta è presente il nome del documento
                    return $query->where('documents.id', $request->user_id);
            })->when($request->searchTag, function ($query) use ($request) { // Verifica se nella richiesta è presente il tag
                return $query->whereHas('tags', function ($tagQuery) use ($request) {
                    $tagQuery->where('tags.id', $request->searchTag);
                });
            })->when($request->extension, function ($query) use ($request) { // Verifica se nella richiesta è presente l'estensione
                return $query->where('documents.id', $request->extension);
            });
            })->when($request->mime, function ($query) use ($request) { // Verifica se nella richiesta è presente il mime
                return $query->where('documents.id', $request->mime);
            })->when($request->searchNote, function ($query) use ($request) { // Verifica se nella richiesta è presente la nota
                return $query->whereHas('note', function($queryNote) use ($request) {
                    $queryNote->where('notes.id', $request->searchNote);
                });
            })->when($request->searchUser, function ($query) use ($request) { // Verifica se nella richiesta è presente la nota
                return $query->whereHas('user', function($userQuery) use ($request) {
                    $userQuery->where('users.id', $request->searchUser);
                });
            });
    }
}
``` 

All'interno dei model oltre alle fillable si possono avere:

``` PHP 
    
    // Attributi che vengono nascosti dalla serializzazione
    protected $hidden = [
        'password',
        'remember_token',
    ];


    // Campi che subiscono il casting
    protected function casts(): array
    {
        return [
            'email_verified_at' => 'datetime',
            'password' => 'hashed',
        ];
    }
```


## Comando model

Questo comando crea un model
``` bash
php artisan make:model nomeModel
```
Questo comando crea un sia il model che la migration
``` bash
php artisan make:model nomeModel -m
```
---
<br>

# Route

Dopo i models, si passa a definire le route nel file **web.php** oppure nel file **auth.php**.

Esempio: 

``` PHP 


  // Route che rimanda alla dashboard utente
Route::get('/dashboard', function() {
    if(Auth::user()->usertype === 'user'){

        $users = UserResource::collection(User::all());
        $tags = Tag::whereHas('users', function($query){
            $query->where('usertype', 'user');

        })
        ->latest()
        ->take(3)
        ->get();

        $tags = TagResource::collection($tags);

        return Inertia('Dashboard',[
            'users' => $users,
            'tags' => $tags
        ]);
    }else{

        $users = UserResource::collection(User::all());
        $tags = Tag::whereHas('users', function($query){
            $query->where('usertype', 'admin');
        })
        ->latest()
        ->take(3)
        ->get();

        $tags = TagResource::collection($tags);

        return Inertia('Admin/Dashboard',[
            'users' => $users,
            'tags' => $tags
        ]);
    }
})->middleware(['auth', 'verified'])->name('dashboard');
```

Ogni route ha una CRUD diversa, possono essere diversificate tra di loro raggrupandole in middleware oppure utilizzando dei nomi.

Possono essere scritte in maniera diversa

Primo metodo

``` PHP 

    Route::get('/profile', [ProfileUserController::class, 'edit'])->name('profile.edit');

```

``` PHP 

    Route::get('/profile', [ProfileUserController::class@index]);

```

oppure 

``` PHP 

    Route::resource('documents', DocumentController::class);

```

Questo ultimo metodo permette di scrivere meno codice e creare automaticamente le route per tutte le azioni CRUD, ovviamente bisogna specificarlo, difatti inizieranno con **documents.nomeAzioneCrud**

<br>

# Middleware

I middleware servono per raggruppare più route alla volta, alla creazione del progetto ne vengono create alcune di default, ognuna gestisce qualcosa di diverso, un esempio:

Admin.php

``` PHP 
namespace App\Http\Middleware;

use Closure;
use Illuminate\Http\Request;
use Illuminate\Support\Facades\Auth;
use Inertia\Inertia;
use Symfony\Component\HttpFoundation\Response;

class Admin{

    // Rimanda alla dashboard utente se l'utente verificato non è un admin
    public function handle(Request $request, Closure $next){
        if(Auth::user()->usertype != 'admin'){
            return Inertia('Dashboard');
        }
        return $next($request);
    }
}

```

In concomitanza a questo, bisogna aggiungere nel file **app.php** che si trova nella cartella **bootstrap** il nuovo middleware creato tramite l'utilizzo di alias.

app.php 

``` PHP 


namespace App\Http\Middleware;

use Closure;
use Illuminate\Http\Request;
use Illuminate\Support\Facades\Auth;
use Inertia\Inertia;
use Symfony\Component\HttpFoundation\Response;

    // Definisce un alias per il middleware
    $middleware->alias([
        'admin' => \App\Http\Middleware\Admin::class,
    ]);

```

## Comando middleware 

Comando per creare una middleware 

``` bash
php artisan make:middleware nomeMiddleware 
```
<br>

# Controller 

Tutti i controller hanno la stessa struttura, contengono le CRUD:

- Create, corrisponde alla POST
- Read, corrisponde alla GET
- Update, corrisponde al PUT
- Delete, corrisponde alla DELETE

Laravel ne crea uno default chiamato **Controller.php** da cui si estendono tutti gli altri. 

Esempio:

DocumentController.php

``` PHP

namespace App\Http\Controllers;

use App\Models\Tag;
use App\Models\Note;
use App\Models\User;
use Inertia\Inertia;
use App\Models\Document;
use Illuminate\Http\Request;
use App\Http\Resources\TagResource;
use App\Http\Resources\NoteResource;
use App\Http\Resources\UserResource;
use Illuminate\Support\Facades\Auth;
use Illuminate\Support\Facades\Gate;
use Illuminate\Support\Facades\Storage;
use Illuminate\Database\Eloquent\Builder;
use App\Http\Requests\StoreDocumentRequest;
use App\Http\Requests\UpdateDocumentRequest;
use App\Http\Resources\DocumentResource as DocumentResource;

class DocumentController extends Controller
{
    // Funzione che gestisce l'index con tutti i documenti creati sia da user che admin
    public function index(Request $request){

        // Permesso che permette di visualizzare l'index solo a chi autorizzato
        Gate::authorize('documents.index', [Auth::user()]);

        // Permette di cercare il documento includendo tags e users
        $documentQuery = Document::search($request);
        $users = UserResource::collection(User::all());
        $tags = TagResource::collection(Tag::all());
        $notes = NoteResource::collection(Note::all());

        return Inertia('Document/Index', [
            'documents' => DocumentResource::collection(
                $documentQuery->paginate(5) // Permette di mettere 5 documenti per pagina
            ),
            'tags' =>  $tags,
            'notes' => $notes,
            'users' => $users,
            'search' => request('search') ?? '',
            'searchUser' => request('searchUser') ?? '',
            'searchNote' => request('searchNote') ?? '',
            'searchTag' => request('searchTag') ?? ''
        ]);
    }

    // Funzione che applica la ricerca nella barra
    protected function applySearch(Builder $query, $search) // Applica la ricerca
    {
        return $query->when($search, function ($query, $search) { // Raggruppa le condizioni
            $query->where('document.name', 'like', '%' . $search . '%') // Verifica se nella richiesta è presente il nome
                   ->orWhere('document.extension', 'like', '%' . $search . '%') // Verifica se nella richiesta è presente l'estensione
                   ->orWhere('document.mime', 'like', '%' . $search . '%') // Verifica se nella richiesta è presente il mime
                   ->orWhereHas('tags.name', 'like', '%' . $search . '%') // Verifica se nella richiesta è presente il tag
                   ->orWhereHas('note.name', 'like', '%' . $search . '%') // Verifica se nella richiesta è presente il contenuto della nota
                   ->orWhereHas('user.name', 'like', '%' . $search . '%'); // Verifica se nella richiesta è presente il contenuto della nota
            });
    }

    // Permette di creare il documento
    public function create() {

       Gate::authorize('documents.create', [Auth::user()]);

        $tags = TagResource::collection(Tag::all());
        $documents = DocumentResource::collection(Document::all());
        $users = UserResource::collection(User::all());
        $notes = NoteResource::collection(Note::all());

        return Inertia('Document/Create', [
            'documents' => $documents,
            'tags' => $tags,
            'users' => $users,
            'notes' => $notes
        ]);
    }

    // Permette di eseguire la richiesta di salvataggio della creazione
    public function store(StoreDocumentRequest $request) {

        Gate::authorize('documents.store', [Auth::user()]);

            // Controlla se la richiesta ha l'icona
            if ($request->hasFile('icon')) {
                // Se presente salva l'icona nella cartella icons
                $iconPath = $request->file('icon')->store('icons', 'public');
            } else {
                // Se non è presente l'icona sarà nulla
                $iconPath = null;
            }

            // Permette di creare il documento
            $document = Document::create([
                'name' => $request->name,
                'path' => $request->path,
                'icon' => $iconPath,
                'mime' => $request->mime,
                'user_id' => $request->user_id,
                'note_id' => $request->note_id,
                'extension' => $request->extension,
            ]);

              // Controlla se i tag sono presenti
            if ($request->has('tags')) {
                // Se presenti li associa
                $document->tags()->attach($request->tags);
            }

            // Se andata a buon fine ritorna all'index
            return redirect()->route('documents.index')->with('message', 'Document created successfully.');

    }

    // Permette di modificare un documento
    public function edit(Document $document) {

        Gate::authorize('documents.edit', [Auth::user()]);

       $tags = TagResource::collection(Tag::all());
       $users = UserResource::collection(User::all());
       $notes = NoteResource::collection(Note::all());

       $allDocuments = DocumentResource::collection(Document::all());

       return Inertia('Document/Edit', [
            'document' => DocumentResource::make($document), // Permette di creare una nuova istanza
            'tags' => $tags,
            'documents' => $allDocuments,
            'users' => $users,
            'notes' => $notes
       ]);

    }

    // Funzione per l'aggiornamento dell'icona
    public function uploadIcon(Request $request, Document $document) {

        $request->validate([
            'icon' => 'nullable|file|mimes:jpeg,png,jpg,gif,svg|max:2048',
        ]);

        // Se l'icona esiste, viene cancellata e sostituita
        if ($document->icon && Storage::disk('public')->exists($document->icon)) {
            Storage::disk('public')->delete($document->icon);
        }

        // Viene salvata all'interno della cartella
        $iconPath = $request->file('icon')->store('icons', 'public');
        $document->update(['icon' => $iconPath]);

    }


    // Permette di effettuare la richiesta di modifica
    public function update(UpdateDocumentRequest $request, Document $document) {

        Gate::authorize('documents.update', [Auth::user()]);

        // Inizialmente tralascia dalla richiesta l'icona
        $data = $request->except('icon');

        if ($request->has('tags')) {
            $document->tags()->sync($request->tags);
        }

        $document->update($data);

        return redirect()->route('documents.index')->with('message', 'Document updated successfully.');
    }

    // Permette di eliminare un documento
    public function destroy(Document $document) {

       Gate::authorize('documents.destroy', [Auth::user()]);

        $document->delete();

        return redirect()->route('documents.index')->with('message', 'Document deleted successfully.');
    }

}


```
Ovviamente ogni controller e a se, non tutti contengono le stesse funzioni ma tutti svolgono lo stesso compito, quello di eseguire le operazioni CRUD.

Alla creazione del progetto oltre al **controller.php** vengono messi a disposizione altri controller che servono per l'autenticazione dell'utente, invio email, conferma e reset password etc., infatti, esiste di default una cartella denominata **Auth** e questa contiene:

- AuthenticatedSessionController.php 
- ConfirmablePasswordController.php 
- EmailVerificationNotificationController.php
- EmailVerificationPromptController.php
- NewPasswordController.php
- PasswordController.php
- PasswordResetLinkController.php
- RegisteredUserController.php
- VerifyEmailController.php

E poi una classe a parte per il profilo

- ProfileUserController.php

<br>

# Resources 

I dati dei models vengono trasformati in array e sono un ottimo modo per gestire il rendering nel frontend, per esempio:

DocumentResource.php

``` PHP 



namespace App\Http\Resources;

use Illuminate\Http\Request;
use Illuminate\Http\Resources\Json\JsonResource;

class DocumentResource extends JsonResource
{
    public function toArray(Request $request): array
    {
        return [
            'id' => $this->id, // Recupera l'id
            'name' => $this->name, // Recupera il nome
            'icon' => $this->icon, // Recupera l'icona
            'path' => $this->path, // Recupera il path
            'extension' => $this->extension, // Recupera l'estensione
            'mime' => $this->mime, // Recupera il mime
            'user_id' => $this->user_id, // Recupera l'id user
            'note_id' => $this->note_id, // Recupera l'id nota
            'user' => UserResource::make($this->user), // Crea una nuova istanza
            'tags' => TagResource::collection($this->tags), // Trasforma la risorsa in una collezione
            'note' => NoteResource::make($this->note), // Crea una nuova istanza 
            'created_at' => $this->created_at->diffForHumans(), // Formatta la data di creazione
            'updated_at' => $this->updated_at->diffForHumans(), // Formatta la data di modifica
        ];
    }
}

```
La risorsa viene trasformata e nei controller un utilizzo potrebbe essere di questo tipo:

``` PHP 
    $users = UserResource::collection(User::all());
```

# Requests

Definiscono delle regole per la validazione dei dati al momento della richiesta.

Come le resources, esistono anche le requests che possono essere di due tipi:

- Store 
- Update 

Con l'utilizzo di Breeze ne vengono create due di default:

- LoginRequest
- ProfileUpdateRequest

Un esempio di store:

StoreDocumentRequest.php

``` PHP 


namespace App\Http\Requests;

use Illuminate\Foundation\Http\FormRequest;

class StoreDocumentRequest extends FormRequest
{

    public function authorize(): bool  // Se viene impostato a false, questo all'invio della richiesta mostrerà un errore
    {
        return true;
    }

    public function rules(): array  // Regole per la validazione dei dati
    {
        return [
            'name' => 'required|string|max:255',
            'path' => 'required|string|max:255',
            'icon' => 'nullable|image',
            'mime' => 'required|string|max:255',
            'extension' => 'required|string',
            'user_id' => 'required|exists:users,id',
            'note_id' => 'nullable|exists:notes,id',
            'tags' => 'required|exists:tags,id'
        ];
    }

}
```

Questo invece per quanto riguarda l'update:

UpdateDocumentRequest.php

``` PHP 



namespace App\Http\Requests;


use Illuminate\Foundation\Http\FormRequest;

class UpdateDocumentRequest extends FormRequest
{
    public function authorize(): bool
    {
        return true;
    }

    public function rules()
    {
        return [
            'name' => 'string|max:255',
            'path' => 'string',
            'mime' => 'string',
            'extension' => 'string',
            'icon' => 'nullable|image',
        ];
    }


}

```
<br>

# Notifications

Supporto offerto da Laravel per invio di notifiche attraverso vari canali, includendo SMS, email e Slack.

Esempio:

AdminResetPassword.php

``` PHP 

namespace App\Notifications;

use Illuminate\Bus\Queueable;
use Illuminate\Contracts\Queue\ShouldQueue;
use Illuminate\Notifications\Messages\MailMessage;
use Illuminate\Notifications\Notification;

class AdminResetPasswordNotification extends Notification
{
    use Queueable;


    public $token;

    /**
     * Create a new notification instance.
     */
    public function __construct($token)
    {
        $this->token = $token;
    }

    /**
     * Get the notification's delivery channels.
     *
     * @return array<int, string>
     */
    public function via(object $notifiable): array
    {
        return ['mail'];
    }

    /**
     * Essendo che laravel utilizza un url di default per il reset password, ho utilizzato un reset custom. in cui l'url anziche essere /reset-password diventa /admin/reset-password
     */
    public function toMail( $notifiable): MailMessage
    {
        $url = url("/admin/reset-password/{$this->token}?email=" . urlencode($notifiable->email));

        return (new MailMessage)
            ->subject('Reset Password Notification')
            ->line('You are receiving this email because we received a password reset request for your account.')
            ->action('Reset Password', $url)
            ->line('This password reset link will expire in 60 minutes.');
    }

    /**
     * Get the array representation of the notification.
     *
     * @return array<string, mixed>
     */
    public function toArray(object $notifiable): array
    {
        return [
            //
        ];
    }
}
```

Questa classe permette di inviare una notifica custom per il reset password ma come admin, essendo che Laravel di default utilizza una sua notification specifica.

Per poter fare questo, nel caso si utilizzasse come host gmail, bisognerebbe eseguire questi semplici passaggi:

- Andare su **Google Account**

  ![screen](./img/google-account.PNG)
   
- Andare nella voce **Sicurezza**

  ![screen](./img/sicurezza.PNG)

- Attivare autenticazione a due fattori

   ![screen](./img/autenticazione.PNG)

- Cercare nella barra **Password delle app**

   ![screen](./img/app.PNG)

- Impostare la password per l'app

  ![screen](./img/app-password.PNG)

Dopo aver eseguito questo, modificare il file **.env** in questo modo:

``` PHP 
MAIL_MAILER=smtp
MAIL_HOST=smtp.gmail.com
MAIL_PORT=465
MAIL_USERNAME=//email
MAIL_PASSWORD=//bisogna inserire la password generata da google
MAIL_ENCRYPTION=ssl
MAIL_FROM_ADDRESS=//"email"
MAIL_FROM_NAME="${APP_NAME}"

```
E nel model **user.php** bisognerà inserire la funzione per richiamare la classe 

User.php

``` PHP 
    // Permette di inviare la notifica di reset password in base allo usertype
    public function sendPasswordResetNotification($token)
    {
        $user = new User();
        if($user->usertype === 'admin'){
            $this->notify(new AdminResetPasswordNotification($token));
        }else{
            $this->notify(new ResetPassword($token));
        }
    }

```

<br>

## Permessi

Per poter distinguere l'admin dallo user, bisognerà atribuire a questi dei permessi, per esempio uno user non potrà modificare un documento, al contrario di un admin che invece lo potrà fare. 

Per poter fare questo, bisognerà andare nella cartella **providers** e aggiungere nella classe **AppServiceProvider.php**:

AppServiceProvider.php

``` PHP 

namespace App\Providers;

use App\Http\Requests\StoreDocumentRequest;
use App\Models\User;
use Illuminate\Support\Facades\Gate;
use Illuminate\Support\Facades\Vite;
use Illuminate\Support\ServiceProvider;

class AppServiceProvider extends ServiceProvider
{

    public function register(): void
    {
        //
    }

    // Gestisce i permessi alle varie pagine

    public function boot(): void
    {
        Gate::define('documents.index', function (User $user) {
            return $user;
        });

        Gate::define('documents.create', function (User $user) {
            return $user;
        });

        Gate::define('documents.store', function (User $user) {
            return $user;
        });

        Gate::define('documents.edit', function (User $user) {
            return $user->usertype === 'admin';
        });

        Gate::define('documents.update', function (User $user) {
            return $user->usertype === 'admin';
        });

        Gate::define('documents.destroy', function (User $user) {
            return $user->usertype === 'admin';
        });

        Gate::define('tags.index', function (User $user) {
            return $user;
        });

        Gate::define('tags.create', function (User $user) {
            return $user;
        });

        Gate::define('tags.store', function (User $user) {
            return $user;
        });

        Gate::define('tags.edit', function (User $user) {
            return $user->usertype === 'admin';
        });

        Gate::define('tags.update', function (User $user) {
            return $user->usertype === 'admin';
        });

        Gate::define('tags.destroy', function (User $user) {
            return $user->usertype === 'admin';
        });

        Gate::define('folders.index', function (User $user) {
            return $user;
        });

        Gate::define('folders.create', function (User $user) {
            return $user;
        });

        Gate::define('folders.store', function (User $user) {
            return $user;
        });

        Gate::define('folders.edit', function (User $user) {
            return $user->usertype === 'admin';
        });

        Gate::define('folders.update', function (User $user) {
            return $user->usertype === 'admin';
        });

        Gate::define('folders.destroy', function (User $user) {
            return $user->usertype === 'admin';
        });

        Gate::define('subfolders.index', function (User $user) {
            return $user;
        });

        Gate::define('subfolders.create', function (User $user) {
            return $user;
        });

        Gate::define('subfolders.store', function (User $user) {
            return $user;
        });

        Gate::define('subfolders.edit', function (User $user) {
            return $user->usertype === 'admin';
        });

        Gate::define('subfolders.update', function (User $user) {
            return $user->usertype === 'admin';
        });

        Gate::define('subfolders.destroy', function (User $user) {
            return $user->usertype === 'admin';
        });

        Gate::define('notes.index', function (User $user) {
            return $user;
        });

        Gate::define('notes.create', function (User $user) {
            return $user;
        });

        Gate::define('notes.store', function (User $user) {
            return $user;
        });

        Gate::define('notes.edit', function (User $user) {
            return $user->usertype === 'admin';
        });

        Gate::define('notes.update', function (User $user) {
            return $user->usertype === 'admin';
        });

        Gate::define('notes.destroy', function (User $user) {
            return $user->usertype === 'admin';
        });


        Vite::prefetch(concurrency: 3);
    }
}
```
Fatto questo si modificano i controller aggiungendo:

DocumentController.php

``` PHP 

   // Permesso che permette di visualizzare l'index solo a chi autorizzato
        Gate::authorize('documents.index', [Auth::user()]);
```

# Comando Notfication

``` bash
php artisan make:notification nomeNotification
```

# Frontend 

Si utilizza Vue con Inertia, un framework di JS

Prima di avviare l'app, bisognerà installare npm 

``` bash
install npm
```
Dopo aver fatto questo si potrà lanciare il server di Vite

``` bash
npm run dev
```

>[!IMPORTANTE]
>
> Il file di configurazione per Vite viene generato alla creazione del progetto.

Come default, viene messa a disposizione una vista in Blade che rappresenta un template principale per le pagine dell'applicazione.

``` PHP
    <!DOCTYPE html>
<html lang="{{ str_replace('_', '-', app()->getLocale()) }}">
    <head>
        <meta charset="utf-8">
        <meta name="viewport" content="width=device-width, initial-scale=1">

        <title inertia>{{ config('app.name', 'Laravel') }}</title>

        <!-- Fonts -->
        <link rel="preconnect" href="https://fonts.bunny.net">
        <link href="https://fonts.bunny.net/css?family=figtree:400,500,600&display=swap" rel="stylesheet" />

        <!-- Scripts -->
        @routes
        @vite(['resources/js/app.js', "resources/js/Pages/{$page['component']}.vue"])
        @inertiaHead
    </head>
    <body class="font-sans antialiased">
        @inertia
    </body>
</html>

```
# Components 

Alla creazione del progetto, vengono messi a disposizione dei componenti prefabbricati tipo:

- Checkbox.vue
- DangerButton.vue
- Modal.vue
- NavLink.vue
- DropdownLink.vue
- Pagination.vue
- ApplicationLogo.vue
- Dropdown.vue
- InputError.vue
- InputLabel.vue
- PrimaryButton.vue
- ResponsiveNavLink.vue
- SecondaryButton.vue
- TextInput.vue

Possono essere importati in questo modo:

``` JS
  import PrimaryButton from "@/Components/PrimaryButton.vue";
```
e utilizzati così:

``` JS
   <InputError
        class="mt-2"
        :message="form.errors.extension"
    />
```
Esempio:

TextInput.vue

``` JS
    <script setup>
    import { onMounted, ref } from 'vue';

    const model = defineModel({
        type: String,
        required: true,
    });

    const input = ref(null);

    onMounted(() => {
        if (input.value.hasAttribute('autofocus')) {
            input.value.focus();
        }
    });

    defineExpose({ focus: () => input.value.focus() });
    </script>

    <template>
        <input
            class="rounded-md border-gray-300 shadow-sm focus:border-indigo-500 focus:ring-indigo-500"
            v-model="model"
            ref="input"
        />
    </template>
```

# Layout

Funzionano come i componenti, possono essere importati e utilizzato allo stesso modo. 

Come default ne genera due:

- AuthenticatedLayout.vue
- GuestLayout.vue

Esempio:

GuestLayout.vue

```JS

<script setup>
import ApplicationLogo from '@/Components/ApplicationLogo.vue';
import { Link } from '@inertiajs/vue3';
</script>

<template>
    <div
        class="flex min-h-screen flex-col items-center bg-gray-100 pt-6 sm:justify-center sm:pt-0"
    >
        <div
            class="mt-6 w-full overflow-hidden bg-white px-6 py-4 shadow-md sm:max-w-md sm:rounded-lg"
        >
            <slot />
        </div>
    </div>
</template>

```
# Pages

Principalmente sono le pagine che elaborano ed eseguono il rendering dei dati delle tabelle

Come default ne vengono generati alcuni sotto la cartella **Auth**:

- ConfirmPassword.vue
- ForgotPassword.vue
- Login.vue
- Register.vue
- ResetPassword.vue
- VerifyEmail.vue
- ApplicationLogo.vue
- Dropdown.vue

e altri sotto la cartella **profile** che a sua volta contiene una sottocartella **Partials**

- Edit.vue
- DeleteUserForm.vue 
- UpdatePasswordForm.vue
- UpdateProfileInformationForm.vue 


Esempio:

Create.vue

```JS
<script setup>
import AuthenticatedLayout from "@/Layouts/AuthenticatedLayout.vue";
import { Head, Link, useForm, usePage } from "@inertiajs/vue3";
import InputError from "@/Components/InputError.vue";
import PrimaryButton from "@/Components/PrimaryButton.vue";
import { computed } from "vue";

// Props che definiscono gli oggetti presi dal backend
const props = defineProps({
    users : {
        type: Object
    },
    tags:{
        type: Object
    },
    notes: {
        type: Object
    }
});

// Viene richiamato l'oggetto documents dalle props
const documents = usePage().props.documents

// Viene settato un form con campi vuoti
const form = useForm({
    name: "",
    path: "",
    icon: null,
    mime: "",
    extension: "",
    user_id: "",
    note_id: "",
    tags: ""
});

// Funzione che permette di filtrare gli user in base allo user registrato, se in quel momento è registrato uno user normale, verrà mostrato solo quello
const filteredUsers = computed(() => {
    const currentUser = usePage().props.auth.user
    return props.users.data.filter(user => user.id === currentUser.id);
});

// Funzione che permette di filtrare le note create da quello specifico user
const filteredNotes = computed(() => {
    const currentUser = usePage().props.auth.user
    return props.notes.data.filter(note =>{
        if(currentUser.usertype === 'user'){
            return note.user_id === currentUser.id;
        }else{
            return note.user_id === currentUser.id
        }
    });
})

const submit = () => {

    // Verifica all'interno dei documenti quelli con lo stesso nome
    let documentExist = documents.data.some(doc => doc.name.toLowerCase() === form.name.toLowerCase() || doc.name.toUpperCase() === form.name.toUpperCase());
    if(documentExist){
        // Messaggio di errore se il documento ha lo stesso nome di uno già creato
        alert("Document already exists");
    } else {
            // Se andato a buon fine esegue la richiesta
            form.post(route("documents.store"), {
            preserveScroll: true,
        });
    }
};

// Gestisce l'upload dell'icona
const handleFileUpload = (event) => {
    form.icon = event.target.files[0];
};

</script>

<template>
    <Head title="Documents" />

    <AuthenticatedLayout>
        <template #header>
            <h2 class="font-semibold text-xl text-gray-800 leading-tight">
                Documents
            </h2>
        </template>
        <div class="max-w-7xl mx-auto py-6 sm:px-6 lg:px-8">
            <div class="lg:grid lg:grid-cols-12 lg:gap-x-5">
                <div class="space-y-6 sm:px-6 lg:px-0 lg:col-span-12">
                    <form @submit.prevent="submit"> <!--Questo impedisce il normale comportamento del submit-->
                        <div class="shadow sm:rounded-md sm:overflow-hidden">
                            <div class="bg-white py-6 px-4 space-y-6 sm:p-6">
                                <div>
                                    <h3
                                        class="text-lg leading-6 font-medium text-gray-900"
                                    >
                                        Document Information
                                    </h3>
                                    <p class="mt-1 text-sm text-gray-500">
                                        Use this form to create a new document.
                                    </p>
                                </div>

                                <div class="grid grid-cols-6 gap-6">
                                    <div class="col-span-6 sm:col-span-3">
                                        <label
                                            for="name"
                                            class="block text-sm font-medium text-gray-700"
                                            >Name</label
                                        >
                                        <!--Prende il valore inserito e lo sostituisce nel form-->
                                        <input
                                            v-model="form.name"
                                            type="text"
                                            class="mt-1 block w-full border border-gray-300 rounded-md shadow-sm py-2 px-3 focus:outline-none focus:ring-indigo-500 focus:border-indigo-500 sm:text-sm"
                                            :class="{
                                                'text-red-900 focus:ring-red-500 focus:border-red-500 border-red-300':
                                                    form.errors.name,
                                            }"
                                        />
                                        <!--Componente che gestisce gli errori di input-->
                                        <InputError
                                            class="mt-2"
                                            :message="form.errors.name"
                                        />
                                    </div>

                                    <div class="col-span-6 sm:col-span-3">
                                        <label
                                            for="path"
                                            class="block text-sm font-medium text-gray-700"
                                            >Path</label
                                        >
                                        <input
                                            v-model="form.path"
                                            type="text"
                                            class="mt-1 block w-full border border-gray-300 rounded-md shadow-sm py-2 px-3 focus:outline-none focus:ring-indigo-500 focus:border-indigo-500 sm:text-sm"
                                            :class="{
                                                'text-red-900 focus:ring-red-500 focus:border-red-500 border-red-300':
                                                    form.errors.path,
                                            }"
                                        />
                                        <InputError
                                            class="mt-2"
                                            :message="form.errors.path"
                                        />
                                    </div>

                                    <div class="col-span-6 sm:col-span-3">
                                        <label
                                            for="icon"
                                            class="block text-sm font-medium text-gray-700"
                                            >Icon</label
                                        >
                                        <!--@change quando viene selezionato il file, questo venga effettivamente scelto richiamando la funzione javascript-->
                                        <input
                                            type="file"
                                            id="icon"
                                            @change="handleFileUpload"
                                            class="mt-1 block w-full border border-gray-300 rounded-md shadow-sm py-2 px-3 focus:outline-none focus:ring-indigo-500 focus:border-indigo-500 sm:text-sm"
                                            :class="{
                                                'text-red-900 focus:ring-red-500 focus:border-red-500 border-red-300':
                                                    form.errors.icon,
                                            }"
                                        />
                                        <InputError
                                            class="mt-2"
                                            :message="form.errors.icon"
                                        />
                                    </div>

                                    <div class="col-span-6 sm:col-span-3">
                                        <label
                                            for="mime"
                                            class="block text-sm font-medium text-gray-700"
                                            >Mime</label
                                        >
                                        <input
                                            v-model="form.mime"
                                            type="text"
                                            id="mime"
                                            autocomplete="mime"
                                            class="mt-1 block w-full border border-gray-300 rounded-md shadow-sm py-2 px-3 focus:outline-none focus:ring-indigo-500 focus:border-indigo-500 sm:text-sm"
                                            :class="{
                                                'text-red-900 focus:ring-red-500 focus:border-red-500 border-red-300':
                                                    form.errors.mime,
                                            }"
                                        />
                                        <InputError
                                            class="mt-2"
                                            :message="form.errors.mime"
                                        />
                                    </div>

                                    <div class="col-span-6 sm:col-span-3">
                                        <label
                                            for="extension"
                                            class="block text-sm font-medium text-gray-700"
                                            >Extension</label
                                        >
                                        <input
                                            v-model="form.extension"
                                            type="text"
                                            id="extension"
                                            autocomplete="extension"
                                            class="mt-1 block w-full border border-gray-300 rounded-md shadow-sm py-2 px-3 focus:outline-none focus:ring-indigo-500 focus:border-indigo-500 sm:text-sm"
                                            :class="{
                                                'text-red-900 focus:ring-red-500 focus:border-red-500 border-red-300':
                                                    form.errors.extension,
                                            }"
                                        />
                                        <InputError
                                            class="mt-2"
                                            :message="form.errors.extension"
                                        />
                                    </div>

                                    <div class="col-span-6 sm:col-span-3">
                                        <label
                                            for="tags"
                                            class="block text-sm font-medium text-gray-700"
                                            >Tag</label
                                        >
                                        <select
                                            v-model="form.tags"
                                            multiple
                                            id="tags"
                                            class="mt-1 block w-full bg-white border border-gray-300 rounded-md shadow-sm py-2 px-3 focus:outline-none focus:ring-indigo-500 focus:border-indigo-500 sm:text-sm"
                                            :class="{
                                                'text-red-900 focus:ring-red-500 focus:border-red-500 border-red-300':
                                                    form.errors.tags,
                                            }"
                                        >
                                            <option
                                                v-for="tag in tags.data"
                                                :key="tag.id"
                                                :value="tag.id"
                                            >
                                                {{ tag.name }}
                                            </option>
                                        </select>
                                        <InputError
                                            class="mt-2"
                                            :message="form.errors.tags"
                                        />
                                    </div>


                                    <div class="col-span-6 sm:col-span-3">
                                        <label
                                            for="user_id"
                                            class="block text-sm font-medium text-gray-700"
                                            >User</label
                                        >
                                        <select
                                            v-model="form.user_id"
                                            id="user_id"
                                            class="mt-1 block w-full bg-white border border-gray-300 rounded-md shadow-sm py-2 px-3 focus:outline-none focus:ring-indigo-500 focus:border-indigo-500 sm:text-sm"
                                            :class="{
                                                'text-red-900 focus:ring-red-500 focus:border-red-500 border-red-300':
                                                    form.errors.user_id,
                                            }"
                                        >
                                            <option value="">
                                                Select an user
                                            </option>
                                            <option
                                                v-for="user in filteredUsers"
                                                :key="user.id"
                                                :value="user.id"
                                            >
                                                {{ user.name }}
                                            </option>
                                        </select>
                                        <InputError
                                            class="mt-2"
                                            :message="form.errors.user_id"
                                        />
                                    </div>

                                    <div class="col-span-6 sm:col-span-3">
                                        <label
                                            for="note_id"
                                            class="block text-sm font-medium text-gray-700"
                                            >Note</label
                                        >
                                        <select
                                            v-model="form.note_id"
                                            id="note_id"
                                            class="mt-1 block w-full bg-white border border-gray-300 rounded-md shadow-sm py-2 px-3 focus:outline-none focus:ring-indigo-500 focus:border-indigo-500 sm:text-sm"
                                            :class="{
                                                'text-red-900 focus:ring-red-500 focus:border-red-500 border-red-300':
                                                    form.errors.note_id,
                                            }"
                                        >
                                            <option value="">
                                                Select an note
                                            </option>
                                            <option
                                                v-for="note in filteredNotes"
                                                :key="note.id"
                                                :value="note.id"
                                            >
                                                {{ note.name }}
                                            </option>
                                        </select>
                                        <InputError
                                            class="mt-2"
                                            :message="form.errors.note_id"
                                        />
                                    </div>

                                </div>

                            </div>
                            <div
                                class="px-4 py-3 bg-gray-50 text-right sm:px-6"
                            >
                            <!--Link che rimanda all'index-->
                                <Link
                                    :href="route('documents.index')"
                                    class="inline-flex items-center px-4 py-2 border border-transparent text-sm font-medium rounded-md text-indigo-700 bg-indigo-100 hover:bg-indigo-200 focus:outline-none focus:ring-2 focus:ring-offset-2 focus:ring-indigo-500 mr-4"
                                >
                                    Cancel
                                </Link>
                                <PrimaryButton
                                type="submit"
                                class="bg-indigo-600 border border-transparent rounded-md shadow-sm py-2 px-4 inline-flex justify-center text-sm font-medium text-white hover:bg-indigo-700 focus:outline-none focus:ring-2 focus:ring-offset-2 focus:ring-indigo-500"
                                >
                                Save
                              </PrimaryButton>
                            </div>

                            </div>
                    </form>
                </div>
            </div>
        </div>
    </AuthenticatedLayout>
</template>
```
