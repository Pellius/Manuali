# MANUALE ADMIN

## Inizio

>[!IMPORTANTE]
> 
>Questo è il manuale admin, tutto quello che verrà scritto sarà inerente esclusivamente al come funziona l'applicazione lato admin

<br>

# Funzionamento Applicazione

>[!IMPORTANTE]
>
>A differenza dello utente normale, per essere admin bisogna cambiare lo usertype dal DB:
>
>![screen](./img/usertype-admin.PNG)

<br>

1. Appena viene avviato il server, compare questa pagina iniziale in cui si possono trovare due scritte, **Log in** e **Register**, se si schiaccia sul **Log in** si viene indirizzati alla pagina di login, invece, se si schiaccia sul **register**, si viene mandati alla pagina di registrazione

   ![screen](./img/inizio.PNG)

2. Partendo dal register, si ha un semplice form vuoto composto da:
    
    - Name  

    - Email: deve contenere @ e deve finire con .com, .it, .libero etc.

    - Password: almeno 8 caratteri

    - Confirm Password

   Fine del form:

    - Register: bottone che schiacciato effettua la registrazione e in base al tipo di utente rimanda alla dashboard corretta

    - Already register: link che schiacciato rimanda alla pagina di login

       ![screen](./img/form-register.PNG)

3. Nel caso in cui un admin sia registrato, dovrà schiacciare il link **already register** per essere rimandato alla pagina di login

   Si ha un semplice form vuoto formato da:

    - Email

    - Password

   Fine del form:

    - Remember Me: checkbox che spuntata salva la password 
   
    - Forgot your password

    - You're not registered: link che schiacciato rimanda alla pagina di registrazione

    - Log in: bottone che schiacciato effettua il login e rimanda alla dashboard

        ![screen](./img/form-login.PNG)

4. Nel caso in cui l'admin non si ricordi la password, dovrà schiacciare il link **forgot your password** per essere rimandato alla pagina d'invio email per il reset password.
    
    Si avrà un semplice form vuoto formato da:

     - Email 

    Fine del form:

    - Email password reset link: bottone che schiacciato manda l'email per il reset della password

    ![screen](./img/forgot-password.PNG)

   Se tutto andato a buon fine verrà mostrato un messaggio di conferma:

    ![screen](./img/forgot-password-success.PNG)

5. Dopo aver richiesto il link per il reset password, bisognerà andare sulla casella di posta email e vedere se il link è arrivato

    ![screen](./img/link-reset-password.PNG)

   Bisognerà schiacciare sul bottone per essere rimandati al reset password

   Si avrà un semplice form vuoto formato da:

     - Email

     - Password

     - Confirm password

   Fine del form:

    - Reset password: bottone che schiacciato resetta la password e rimanda al login

    ![screen](./img/form-reset-password.PNG)

   Se tutto andato a buon fine, la pagina dovrà apparire così:

    ![screen](./img/form-reset-password-success.PNG)

6. Fatto il login in modo corretto, si viene reindirizzati nella propria dashboard 

   La dashboard è composta da:

    - Scritta con "You're logged in", per avvisare che l'admin è autenticato

    - Una barra di navigazione con dei link che portano a varie sezioni:

        - Documents

        - Tags 

        - Folders

        - Subfolders 

        - Notes

    - A destra si può trovare il nome dell'admin, schiacciando si apre una selezione:

        - Profile

        - Logout: link che schiacciato rimanda alla pagina iniziale

    - In basso, quando verranno creati compariranno gli ultimi tre tag ordinati in base alla data creazione

    - Alla fine, due bottoni, **change password** e **create user**, uno per il cambio password e l'altro per creare utenti 
        
    - Change password, composto da un semplice form:

        - Email 

       Fine del form:

        - Email password reset link: bottone che schiacciato manda l'email per il reset della password

        ![screen](./img/change-password.PNG)

    - Create user, composto da un semplice form 

        - Name  

        - Email: deve contenere @ e deve finire con .com, .it,.libero etc.

        - Password: almeno 8 caratteri

        - Confirm Password

      Fine del form:

        - Create user: bottone che schiacciato crea l'utente e lo aggiunge al DB

        ![screen](./img/create-user.PNG)

    Dashboard vuota

    ![screen](./img/dashboard-vuota.PNG)

    Dashboard con inserimento tag 

    ![screen](./img/dashboard-con-tag.PNG)

   Profilo:
     
     - Profile information, semplice form formato da:

        - Name

        - Email

       Fine del form: 

        - Save: bottone che schiacciato salva le modifiche 
    
    - Update password, semplice form formato da:

       - Current password

       - New password

       - Confirm Password

      Fine del form: 

       - Save: bottone che schiacciato salva le modifiche 

    - Delete account, semplice form formato da: 

       - Bottone che schiacciato apre un modale dove chiede se si è sicuri di cancellare l'account
        
    - Confirm delete, semplice form formato da:

       - Una casella di testo in cui bisogna inserire la password usata in fase di registrazione o in fase di aggiornamento

      Fine del form:
    
       - Cancel: bottone che schiacciato annulla l'operazione 

       - Delete account: bottone che schiacciato elimina l'account se la password inserita è corretta   

    Profilo 

    ![screen](./img/profilo.PNG)

    Impostazioni profilo salvate 

    ![screen](./img/impostazioni-profilo-salvate.PNG)

    Password aggiornata salvata

    ![screen](./img/password-aggiornata-salvata.PNG)

    Conferma eliminazione account

    ![screen](./img/conferma-cancellazione-account.PNG)

7. Prima sezione: Documents

   La sezione è formata da:

    - Barra di ricerca per cercare i documenti, la ricerca avviene per:

        - Name

        - Extension

        - Mime

        - Tag 

        - User 

        - Note 

    - A lato della barra si possono trovare tutti i filtri, all'inizio vuoti

    - Sotto, quando aggiunti, compariranno i documenti creati con paginazione, una nuova pagina si aggiungerà dopo 5 documenti creati e a fianco due link, **edit** e **delete**

    - Sopra ai filtri, sulla destra, si trova un bottone che schiacciato rimanda alla pagina per la creazione di un nuovo documento 

   Sezione documenti vuota

    ![screen](./img/sezione-documenti.PNG)  

   Creazione documento

   Form formato da:

    - Name: **richiesto**, se il nome del documento è uguale a quello di uno già esistente compare un messaggio di errore

    - Icon: **richiesto**

    - Extension: **richiesto**, rimangono salvate alla creazione di un altro documento

    - Path: **richiesto**

    - Mime: **richiesto**, rimangono salvati alla creazione di un altro documento

    - Tag: **richiesto**, selezione dei tag creati dall'admin autenticato in quel momento e possono essere selezionati più di uno

    - User: **richiesto**, selezione dell'admin autenticato in quel momento

    - Note: **opzionale**, il documento può anche non contenere una nota e possono essere selezionate più di una, se non viene selezionata nessuna compare la   scritta **No note**

   Fine del form:
    
    - Cancel: bottone che schiacciato annulla la creazione 

    - Save: bottone che schiacciato crea il documento e lo aggiunge 

   Creazione 

    ![screen](./img/creazione-documento.PNG)  

   Messaggio creazione

    ![screen](./img/messaggio-creazione-documento.PNG)  

   Modifica documento

   Form formato da:

    - Name: **opzionale**, se il nome del documento è uguale a quello di uno già esistente compare un messaggio di errore

    - Icon: **opzionale**

    - Extension: **opzionale**, rimangono salvate alla creazione di un altro documento

    - Path: **opzionale**

    - Mime: **opzionale**, rimangono salvati alla creazione di un altro documento

    - Tag: **opzionale**, selezione dei tag creati dall'admin 
    autenticato in quel momento e possono essere selezionati più di uno

    - User: **opzionale**, selezione dell'admin autenticato in quel momento

    - Note: **opzionale**, il documento può anche non contenere una nota e possono essere selezionate più di una, se non viene selezionata nessuna compare la scritta **No note**

   Fine del form:
    
    - Cancel: bottone che schiacciato annulla la modifica 

    - Save: bottone che schiacciato modifica il documento e lo aggiunge 

   Modifica 

    ![screen](./img/modifica-documento.PNG)  

   Messaggio modifica

   ![screen](./img/messaggio-modifica-documento.PNG)  


   Cancellazione documento

   ![screen](./img/cancellazione-documento.PNG)  

   Messaggio cancellazione

   ![screen](./img/messaggio-cancellazione-documento.PNG)  


   Documento senza nota 

  ![screen](./img/documento-senza-nota.PNG)  

   Documento con nota 

   ![screen](./img/documento-con-nota.PNG)  

   Ricerca per nome

   ![screen](./img/ricerca-documento.PNG)  

   Filtro per nome

  ![screen](./img/filtro-documento.PNG)  

   Errore nome documento 

  ![screen](./img/errore-documento.PNG)  

8. Seconda sezione: Tags

   La sezione è formata da:

    - Barra di ricerca per cercare i tag, la ricerca avviene per:

        - Name 

        - User 

    - A lato della barra si possono trovare tutti i filtri, all'inizio vuoti

    - Sotto, compariranno i tag creati con la paginazione, una nuova pagina si aggiungerà dopo 5 tag creati e a fianco due link, **edit** e **delete**

    - Sopra ai filtri, sulla destra, si trova un bottone che schiacciato rimanda alla pagina per la creazione di un nuovo tag 

   Sezione tag vuota

    ![screen](./img/sezione-tag.PNG)  

   Creazione tag

   Form formato da:

    - Name: **richiesto**, se il nome del tag è uguale a quello di uno già esistente compare un messaggio di errore

    - User: **richiesto**, selezione dello user, l'admin può scegliere se associare il tag a un solo user o a più user

   Fine del form:
    
    - Cancel: bottone che schiacciato annulla la creazione 

    - Save: bottone che schiacciato crea il tag e lo aggiunge

   Creazione 

    ![screen](./img/creazione-tag.PNG)  

   Messaggio creazione

    ![screen](./img/messaggio-creazione.PNG)  

  Modifica tag

   Form formato da:

    - Name: **opzionale**, se il nome del tag è uguale a quello di uno già esistente compare un messaggio di errore

    - User: **opzionale**, selezione dell'admin autenticato in quel momento

   Fine del form:
    
    - Cancel: bottone che schiacciato annulla la modifica 

    - Save: bottone che schiacciato modifica il tag e lo aggiunge

   Modifica 

   ![screen](./img/modifica-tag.PNG)  

   Messaggio modifica

  ![screen](./img/messaggio-modifica-tag.PNG)  


   Cancellazione tag 

   ![screen](./img/cancellazione-tag.PNG)  

   Messaggio cancellazione

   ![screen](./img/messaggio-cancellazione-tag.PNG)  


   Sezione con almeno uno user associato

   ![screen](./img/sezione-con-tag.PNG)  

   Sezione con più user associati

   ![screen](./img/sezione-con-piu-user.PNG)  

   Ricerca per nome

   ![screen](./img/ricerca-tag.PNG)  

   Filtro per nome

  ![screen](./img/filtro-tag.PNG)  

   Errore nome tag 

   ![screen](./img/errore-tag.PNG)  

9. Terza sezione: Folders

   La sezione è formata da:

    - Barra di ricerca per cercare le cartelle, la ricerca avviene per:

        - Name

        - Document

        - User 

        - Subfolder

    - A lato della barra si possono trovare tutti i filtri, all'inizio vuoti

    - Sotto, quando aggiunti, compariranno le cartelle create con paginazione, una nuova pagina si aggiungerà dopo 5 cartelle create e a fianco due link, **edit** e **delete**
    
    - Sopra ai filtri, sulla destra, si trova un bottone che schiacciato rimanda alla pagina per la creazione di una nuova cartella 

   Sezione cartella vuota

    ![screen](./img/sezione-cartella.PNG)  

   Creazione Cartella

   Form formato da:

    - Name: **richiesto**, se il nome della cartella è uguale a quella di una già esistente compare un messaggio di errore

    - Icon: **richiesto**

    - Path: **richiesto**

    - User: **richiesto**, selezione dello user autenticato in quel momento

    - Document: **richiesto**, selezione dei documenti creati dall'utente autenticato in quel momento e possono essere selezionati più di uno

    - Subfolder: **opzionale**, il documento può anche non contenere una sottocartella e possono essere selezionate più di una, se non viene selezionata nessuna compare la scritta **No subfolder**

   Fine del form:
    
    - Cancel: bottone che schiacciato annulla la creazione 

    - Save: bottone che schiacciato crea la cartella e la aggiunge

   Creazione

    ![screen](./img/creazione-cartella.PNG)  

   Messaggio creazione

    ![screen](./img/messaggio-creazione-cartella.PNG)  


   Modifica Cartella

   Form formato da:

    - Name: **opzionale**, se il nome della cartella è uguale a quella di una già esistente compare un messaggio di errore

    - Icon: **opzionale**

    - Path: **opzionale**

    - User: **opzionale**, selezione dello user autenticato in quel momento

    - Document: **opzionale**, selezione dei documenti creati dall'utente autenticato in quel momento e possono essere selezionati più di uno

    - Subfolder: **opzionale**, il documento può anche non contenere una sottocartella e possono essere selezionate più di una, se non viene selezionata nessuna compare la scritta **No subfolder**

   Fine del form:
    
    - Cancel: bottone che schiacciato annulla la modifica 

    - Save: bottone che schiacciato modifica la cartella e la aggiunge

   Modifica 

    ![screen](./img/modifica-cartella.PNG) 

    Messaggio modifica

    ![screen](./img/messaggio-modifica-cartella.PNG)  

   Cancellazione cartella 

    ![screen](./img/cancellazione-cartella.PNG) 

    Messaggio cancellazione

    ![screen](./img/messaggio-cancellazione-cartella.PNG)  


   Cartella senza sottocartella 

    ![screen](./img/cartella-senza-sottocartella.PNG)  

   Cartella con sottocartella 

    ![screen](./img/cartella-con-sottocartella.PNG)  

   Ricerca per nome

    ![screen](./img/ricerca-cartella.PNG)  

   Filtro per nome

    ![screen](./img/filtro-cartella.PNG)  

   Errore nome documento 

    ![screen](./img/errore-cartella.PNG)  

10. Quarta sezione: Subfolders

   La sezione è formata da:

  - Barra di ricerca per cercare le sottocartelle, la ricerca avviene per:

    - Name

    - Document

    - User 

   - A lato della barra si possono trovare tutti i filtri, all'inizio vuoti

   - Sotto, quando aggiunti, compariranno le sottocartelle create con paginazione, una nuova pagina si aggiungerà dopo 5 sottocartelle create e a fianco due link, **edit** e **delete**

   - Sopra ai filtri, sulla destra, si trova un bottone che schiacciato rimanda alla pagina per la creazione di una nuova sottocartella

   Sezione sottocartella vuota

   ![screen](./img/sezione-sottocartella.PNG)  

   Creazione Sottocartella

   Form formato da:

   - Name: **richiesto**, se il nome della sottocartella è uguale a quella di una già esistente compare un messaggio di errore

   - Icon: **richiesto**

   - Path: **richiesto**

   - User: **richiesto**, selezione dello user autenticato in quel momento

   - Document: **richiesto**, selezione dei documenti creati dall'utente autenticato in quel momento e possono essere selezionati più di uno

   Fine del form:
    
   - Cancel: bottone che schiacciato annulla la creazione

   - Save: bottone che schiacciato crea la sottocartella e la aggiunge 

   Creazione

   ![screen](./img/creazione-sottocartella.PNG)  


   Messaggio creazione


  ![screen](./img/messaggio-creazione-sottocartella.PNG)  


   Modifica Sottocartella

   Form formato da:

   - Name: **opzionale**, se il nome della sottocartella è uguale a quella di una già esistente compare un messaggio di errore

   - Icon: **opzionale**

   - Path: **opzionale**

   - User: **opzionale**, selezione dello user autenticato in quel momento

   - Document: **opzionale**, selezione dei documenti creati dall'utente autenticato in quel momento e possono essere selezionati più di uno

   Fine del form:
    
   - Cancel: bottone che schiacciato annulla la modifica

   - Save: bottone che schiacciato modifica la sottocartella e la aggiunge 

   Modifica

   ![screen](./img/modifica-sottocartella.PNG)  

   Messaggio modifica

  ![screen](./img/messaggio-modifica-sottocartella.PNG)  

   Cancellazione

   ![screen](./img/cancellazione-sottocartella.PNG)  

   Sottocartella con almeno un documento associato

Messaggio cancellazione

   ![screen](./img/messaggio-cancellazione-sottocartella.PNG)  

    
   ![screen](./img/sottocartella-con-documenti.PNG)  

   Sottocartella con più documenti associati
    
  ![screen](./img/sottocartella-con-piu-documenti.PNG)  

   Ricerca per nome

   ![screen](./img/ricerca-sottocartella.PNG)  

   Filtro per nome

   ![screen](./img/filtro-sottocartella.PNG)  

   Errore nome sottocartella 

  ![screen](./img/errore-sottocartella.PNG)  

10. Quinta sezione: Notes

   La sezione è formata da:

  - Barra di ricerca per cercare le note, la ricerca avviene per:

    - Name

    - User 

   - A lato della barra si possono trovare tutti i filtri, all'inizio vuoti

   - Sotto, quando aggiunti, compariranno le note create con paginazione, una nuova pagina si aggiungerà dopo 5 note create e a fianco due link, **edit** e **delete**

   - Sopra ai filtri, sulla destra, si trova un bottone che schiacciato rimanda alla pagina per la creazione di una nuova nota

   Sezione nota vuota

   ![screen](./img/sezione-nota.PNG)  

   Creazione Nota

   Form formato da:

   - Name: **richiesto**, se il nome della nota è uguale a quella di una già esistente compare un messaggio di errore

   - Content: **richiesto**

   - User: **richiesto**, selezione dell' admin autenticato in quel momento

   Fine del form:
    
   - Cancel: bottone che schiacciato annulla la creazione 

   - Save: bottone che schiacciato creerà la nota e la aggiunge    

   Creazione

   ![screen](./img/creazione-nota.PNG) 


   Messaggio creazione

  ![screen](./img/messaggio-creazione-nota.PNG)  


   Modifica Nota

   Form formato da:

   - Name: **opzionale**, se il nome della nota è uguale a quella di una già esistente compare un messaggio di errore

   - Content: **opzionale**

   - User: **opzionale**, selezione dell' admin autenticato in quel momento

   Fine del form:
    
   - Cancel: bottone che schiacciato annulla la modifica 

   - Save: bottone che schiacciato modifica la nota e la aggiunge    

   Modifica

   ![screen](./img/modifica-nota.PNG) 


   Messaggio modifica

  ![screen](./img/messaggio-modifica-nota.PNG)  

   Cancellazione nota

  ![screen](./img/cancellazione-nota.PNG) 

  Messaggio cancellazione

  ![screen](./img/messaggio-cancellazione-nota.PNG)  


   Sezione con nota
    
  ![screen](./img/sezione-con-nota.PNG)  

   Ricerca per nome

   ![screen](./img/ricerca-nota.PNG)  

   Filtro per nome

   ![screen](./img/filtro-nota.PNG)  

   Errore nome nota 

   ![screen](./img/errore-nota.PNG)  

